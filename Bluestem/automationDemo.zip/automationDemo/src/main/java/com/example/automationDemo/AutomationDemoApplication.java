package com.example.automationDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutomationDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutomationDemoApplication.class, args);
	}

}
